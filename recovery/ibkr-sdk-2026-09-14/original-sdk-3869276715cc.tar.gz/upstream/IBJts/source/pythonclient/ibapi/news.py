"""
Python TWS API Client

Copyright (C) 2013-2026  Interactive Brokers LLC

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
"""

# TWS New Bulletins constants
NEWS_MSG = 1  # standard IB news bulleting message
EXCHANGE_AVAIL_MSG = (
    2  # control message specifying that an exchange is available for trading
)
EXCHANGE_UNAVAIL_MSG = (
    3  # control message specifying that an exchange is unavailable for trading
)
